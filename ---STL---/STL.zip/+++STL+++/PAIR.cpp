#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
    //pair <int,int> p;
    pair <int,string> p;
    cin >> p.first;
    cin >> p.second;
    cout << p.first << endl;
    cout << p.second << endl;
    return 0;
}
